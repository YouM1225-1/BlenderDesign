# SPDX-FileCopyrightText: 2026 Blender Authors
#
# SPDX-License-Identifier: GPL-3.0-or-later

"""
Context manager to capture STDOUT/STDERR while also forwarding to the real output.

Useful so the LLM may use print(..) style debugging and receive the results as part of the response.
"""

__all__ = (
    "CaptureOutput",
)

import io
import sys
from typing import IO, TypeVar

_CaptureOutputT = TypeVar("_CaptureOutputT", bound="CaptureOutput")
_MAX_CAPTURE_CHARS = 1024 * 1024
_TRUNCATED = "\n[output truncated at {:d} characters]".format(_MAX_CAPTURE_CHARS)


class _Tee(io.TextIOBase):
    """Write to both a :class:`io.StringIO` buffer and the original stream."""
    __slots__ = (
        "_buffer",
        "_original",
        "_truncated",
    )

    def __init__(self, original: IO[str]) -> None:
        self._buffer = io.StringIO()
        self._original = original
        self._truncated = False

    def write(self, s: str) -> int:
        self._original.write(s)
        remaining = _MAX_CAPTURE_CHARS - self._buffer.tell()
        if remaining > 0:
            self._buffer.write(s[:remaining])
        if len(s) > remaining:
            self._truncated = True
        return len(s)

    def flush(self) -> None:
        self._original.flush()
        self._buffer.flush()

    def getvalue(self) -> str:
        value = self._buffer.getvalue()
        return value + _TRUNCATED if self._truncated else value


class CaptureOutput:
    """
    Context manager that captures STDOUT & STDERR.

    Output is forwarded to the original streams in real time
    and also stored for retrieval via :meth:`stdout` and :meth:`stderr`.
    """
    _original_out: IO[str]
    _original_err: IO[str]
    _tee_out: _Tee
    _tee_err: _Tee

    __slots__ = (
        "_tee_out",
        "_tee_err",
        "_original_out",
        "_original_err",
    )

    def __enter__(self: _CaptureOutputT) -> _CaptureOutputT:  # noqa: PYI019
        self._original_out = sys.stdout
        self._original_err = sys.stderr
        self._tee_out = _Tee(self._original_out)
        self._tee_err = _Tee(self._original_err)
        sys.stdout = self._tee_out
        sys.stderr = self._tee_err
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> None:
        del exc_type, exc_val, exc_tb
        sys.stdout = self._original_out
        sys.stderr = self._original_err

    @property
    def stdout(self) -> str:
        return self._tee_out.getvalue()

    @property
    def stderr(self) -> str:
        return self._tee_err.getvalue()
